package dit.hua.gr.greenride.web.ui;

public class RideController {
}
