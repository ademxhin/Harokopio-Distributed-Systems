package dit.hua.gr.greenride.service.mapper;

public class BookingMapper {
}
