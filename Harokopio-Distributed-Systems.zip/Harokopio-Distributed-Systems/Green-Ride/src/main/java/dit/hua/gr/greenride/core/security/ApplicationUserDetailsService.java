package dit.hua.gr.greenride.core.security;

public class ApplicationUserDetailsService {
}
