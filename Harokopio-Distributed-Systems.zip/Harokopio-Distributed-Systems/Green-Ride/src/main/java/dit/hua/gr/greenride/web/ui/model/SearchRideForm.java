package dit.hua.gr.greenride.web.ui.model;

public class SearchRideForm {
}
