package dit.hua.gr.greenride.core.port.impl.dto;

/**
 * SendSmsResult DTO.
 */
public record SendSmsResult(boolean sent) {}