package dit.hua.gr.greenride;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenRideApplication {

    public static void main(String[] args) {
        SpringApplication.run(GreenRideApplication.class, args);
    }

}