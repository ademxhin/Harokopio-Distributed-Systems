package dit.hua.gr.greenride.core.repository;

public class RatingRepository {
}
