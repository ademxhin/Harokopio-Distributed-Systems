package dit.hua.gr.greenride.service.impl;

public class BookingServiceImpl {
}
