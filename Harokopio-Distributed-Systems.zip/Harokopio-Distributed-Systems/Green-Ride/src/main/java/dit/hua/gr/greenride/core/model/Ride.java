package dit.hua.gr.greenride.core.model;

public class Ride {
}
