package dit.hua.gr.greenride.core.port.impl;

public class MapsApiPortImpl {
}
