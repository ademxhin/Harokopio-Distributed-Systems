package dit.hua.gr.greenride.config;

public class SchedulingConfig {
}
