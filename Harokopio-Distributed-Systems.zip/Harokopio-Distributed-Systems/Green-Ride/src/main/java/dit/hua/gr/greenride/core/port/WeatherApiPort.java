package dit.hua.gr.greenride.core.port;

public class WeatherApiPort {
}
