package dit.hua.gr.greenride.service.model;

public class RatingView {
}
