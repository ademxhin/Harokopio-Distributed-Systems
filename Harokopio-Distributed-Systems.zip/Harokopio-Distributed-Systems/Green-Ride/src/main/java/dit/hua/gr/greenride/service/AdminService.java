package dit.hua.gr.greenride.service;

public class AdminService {
}
