package dit.hua.gr.greenride.core.model;

public enum BookingStatus {
}
