package dit.hua.gr.greenride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenRideApplicationTests {

	@Test
	void contextLoads() {
	}

}
